echo "RUN AI Test"
/mnt/resource/aipkg/ab_ai_new &
