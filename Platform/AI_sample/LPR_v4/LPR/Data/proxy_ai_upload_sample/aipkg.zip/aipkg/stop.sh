echo "Stop test AI sample"
pkill ab_ai_new